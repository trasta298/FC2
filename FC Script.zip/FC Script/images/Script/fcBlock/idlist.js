Solar 176 solar
Wire 177 wire
Nickel Ore 179 nickelore
GoldPipe 180 goldpipe
Digitalminner 181 digitalminner
Pipe 182 pipe
AutomaticCrafting 188 automaticCrafting
Quartz Ore 189 quartzore
Copper Ore 190 copperore
Apatite Ore 191 apatiteore
Generator 192 generator
Marker 194 marker
Tin Ore 201 tinore
Ponp 202 ponp
WoodEngine 203 woodengine
Industrial Block 204 industrialBlock

Wrench 500
Nickel Ingot 501
Tin Ingot 502
Apatite 503
Copper Ingot 504
Quartz 505
Cupronickel Ingot 506
Tinplate 507
Icchip 508