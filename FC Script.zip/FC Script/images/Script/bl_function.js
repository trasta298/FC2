

function destroyBlock(x,y,z,side){
}

function startDestroyBlock(x,y,z,side){
}

function selectLevelHook(wName,wDir){
}

function leaveGame(thatboolean){
}

function attackHook(attacker,victim){
}



function chatHook(str){
}

function deathHook(attacker,victim){
}

function entityRemovedHook(entity){
}

function entityAddedHook(entity){
}

function levelEventHook(player,eventType,x,y,z,data){
}

function blockEventHook(x,y,z,type,data){
}

function chatReceiveHook(sender,str){
}

function explodeHook(entity,x,y,z,power,onFire){
}

function eatHook(hearts,notHearts){
}
