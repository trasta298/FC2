/*

Frequency Craft 2 v0.0 @trasta298

This mod use BetterStorage Mod by DAW330073

*/

var version = "v0.0";